var width = 500,
    height = 250,
	xPadding = 30,
	yPadding = 40,
	barPadding = 3;

var x = d3.scale.ordinal()
    .rangeRoundBands([xPadding, width]);

var y = d3.scale.linear()
    .range([-yPadding, height]);

var color = d3.scale.linear()
    .range([0, 255]);

var chart = d3.select(".chart")
    .attr("width", width)
    .attr("height", height);
		
var xLabels = d3.time.scale()
	.domain([new Date(2013, 0, 1), new Date(2013,11,31)])
	.range([xPadding,width])

var year = 2009;

d3.csv("meteo.csv", type, function(error, data) {
	x.domain(data.map(function(d) { return d.month; }));
	minT = d3.min(data, function(d) { return d.temperature; });
	maxT = d3.max(data, function(d) { return d.temperature; });
	color.domain([minT,maxT]);
	y.domain([minT,maxT]);
	
	var data=d3.nest()
		.key(function(d) {return d.year;})
	  .key(function(d) {return d.month;})
	  .rollup(function(d) {
	        return {
						year:d3.mean(d,function(g) {return +g.y;}),
						temp:d3.mean(d,function(g) {return +g.temperature;})
	        };
	      })
	  .entries(data);
	
	var bar = chart.selectAll("g")
	  .data(data)
		.enter().append("g")

	var rect = bar.selectAll("rect")
	  .data(function(d){return d.values})
	  .enter()
	  .append("rect")
	  .attr("x",function(d){return x(d.key)})
	  .attr("y",function(d){return height - yPadding})
	  .attr("height",0)
	  .attr("width", width/12-barPadding)
		.attr("fill", function(d) {
		    return "rgb("+ Math.round(color(d.values.temp)) + ",0,0)";
		});
		
	var t = bar.selectAll("text")
		.data(function(d){return d.values})
		.enter()
		.append("text")
		.attr("opacity",0)
		.attr("x",function(d){return x(d.key) + 5})
		.attr("y",function(d){return height - y(d.values.temp) - 2})
		.attr("z-index",10)
		.text(function(d){return Math.round(d.values.temp)})
	
	var title = chart.append("text")
		.attr("class","title")
    .attr("x", 50 )             
    .attr("y", 0 + yPadding)
    .text(year);
		
	var xAxis = d3.svg.axis()
		.scale(xLabels)
		.ticks(d3.time.months)
		.tickFormat(d3.time.format("%b"));
		
	var xAxisObj = chart.append("g")
		.attr("class","x-axis")
		.attr("transform","translate(0,210)")
		.call(xAxis)
	
	xAxisObj.selectAll(".x-axis .tick")
		.attr("transform",function(){
			var t = d3.transform(d3.select(this).attr("transform"));
			newX = t.translate[0]+15;
			return "translate("+newX+","+t.translate[1]+")";
		});
		
	update();
		
	window.focus();
	d3.select(window).on("keydown", function() {
		oldYear = year
	  switch (d3.event.keyCode) {
	    case 37: year = Math.max(2009, year - 1); break;
	    case 39: year = Math.min(2013, year + 1); break;
	  }
	  console.log(year)
		if(!(oldYear === year)){update();}
	});

	function update() {
		rect.transition().duration(500)
	  .attr("height",0)
		.attr("y", height - yPadding);
	  rect.transition().duration(500).delay(500)
	  .attr("height",function(d){if(d.values.year === year){return y(d.values.temp)-yPadding}else{return 0}})
		.attr("y",function(d){if(d.values.year === year){return height - y(d.values.temp)}else{return height - yPadding}});
		title.text(year)
		t.transition().duration(500).attr("opacity",0);
		t.transition().duration(500).attr("opacity",function(d){if(d.values.year === year){return 1}else{return 0}})
	}
});

function type(d) {
	d.year = +d.year;
	d.y = +d.year
	d.temperature = +d.temperature;
	d.month = +d.month;
	d.day = +d.day
	return d;
}